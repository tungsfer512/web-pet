package WebThiTA.dto;

public class userDto {

}
